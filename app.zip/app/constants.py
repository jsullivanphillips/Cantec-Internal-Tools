# app/constants.py
TECH_CATEGORIES = {
    "Senior Tech": ["Adam Bendorffe", "Craig Shepherd", "Jonathan Graves", "James Martyn"],
    "Mid-Level Tech": ["Alex Turko", "Austin Rasmussen", "Kyler Dickey", "Crosby Stewart", "Eric Turko"],
    "Junior Tech": ["Jonathan Palahicky", "Mariah Grier", "Seth Ealing"],
    "Trainee Tech": ["William Daniel", "Kevin Gao", "Hannah Feness", "James McNeil"],
    "Sprinkler Tech": ["Justin Walker", "Colin Peterson"]
}
